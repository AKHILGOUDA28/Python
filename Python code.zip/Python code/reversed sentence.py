sentence = input("Enter a sentence: ").split()
reversed_sentence = " ".join(sentence[::-1])
print(reversed_sentence)
