a = float(input("Enter first number: "))
b = float(input("Enter second number: "))
op = input("Choose + - * / : ")

if op == "+":
    print(a + b)
elif op == "-":
    print(a - b)
elif op == "*":
    print(a * b)
elif op == "/":
    if b != 0:
        print(a / b)
    else:
        print("Error: Division by zero")
else:
    print("Invalid operator")
